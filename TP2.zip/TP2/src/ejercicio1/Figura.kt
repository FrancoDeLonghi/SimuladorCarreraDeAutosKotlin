package ejercicio1

abstract class Figura () {
    abstract  fun getArea() : Double
    abstract  fun getPerimetro() : Double
}