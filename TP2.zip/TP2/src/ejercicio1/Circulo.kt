package ejercicio1

class Circulo(
    var radio : Double
): Elipse (radio, radio) {
}