package ejercicio1

open class Elipse(
    var semimayor : Double = 0.0,
    var semimenor : Double = 0.0
): Figura() {
    init {
        if(semimayor < semimenor) {
            val aux = semimayor
            semimayor = semimenor
            semimenor = aux
        }
    }

    override fun getArea(): Double {
        return Math.PI * semimenor * semimayor
    }

    override fun getPerimetro(): Double {
        return Math.PI * (semimenor + semimayor)
    }
}