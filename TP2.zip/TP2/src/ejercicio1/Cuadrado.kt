package ejercicio1

class Cuadrado(
    var lado : Double
): Rectangulo(lado, lado) {
}