package ejercicio1

open class Rectangulo(
    var alto : Double = 0.0,
    var ancho : Double = 0.0
): Figura() {
    override fun getArea(): Double {
        return alto * ancho
    }

    override fun getPerimetro(): Double {
        return (alto + ancho) * 2
    }
}