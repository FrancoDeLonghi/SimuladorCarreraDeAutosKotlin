package ejercicio1

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() {
    var cuadrado = Cuadrado(30.0)
    println(cuadrado.getArea())
    println(cuadrado.getPerimetro())
}