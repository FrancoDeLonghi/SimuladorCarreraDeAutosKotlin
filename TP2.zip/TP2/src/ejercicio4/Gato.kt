package ejercicio4

class Gato(
    nombre: String,
    edad: Int,
    var color: String
): Mascota(nombre = nombre, edad = edad){
    override fun toString(): String {
        return super.toString() + " Color: ${color}"
    }
}