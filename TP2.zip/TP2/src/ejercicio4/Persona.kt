package ejercicio4

class Persona(
    var nombre: String,
    var direccion: String,
    var telefono: String,
    var mascota: Mascota
) {
    override fun toString(): String {
        return "Dueño: ${nombre} Direccion: ${direccion} Telefono: ${telefono} Mascota: ${mascota}"
    }
}