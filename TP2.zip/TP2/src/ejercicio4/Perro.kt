package ejercicio4

class Perro(
    nombre: String,
    edad: Int,
    var raza : String
): Mascota (nombre = nombre, edad = edad){
    override fun toString(): String {
        return super.toString() + " Raza: ${raza}"
    }
}