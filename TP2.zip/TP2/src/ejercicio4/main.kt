package ejercicio4

fun main(){
    val mascota1 : Gato = Gato ("zoe",1, "Gris y Blanco")
    val mascota2 : Perro = Perro ("kenai",14, "Caniche")

    val persona1 : Persona = Persona ("Mateo", "Honduras", "3562", mascota1)
    val persona2 : Persona = Persona ("Mateo", "Ameghino", "351", mascota2)

    println(persona1.toString())
    println(persona2.toString())
}