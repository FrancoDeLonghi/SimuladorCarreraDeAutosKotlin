package ejercicio4

open class Mascota (
    var nombre : String = "no tiene nombre",
    var edad : Int = 0
){
    override fun toString(): String {
        return "Nombre: ${nombre}, Edad: ${edad}"
    }
}
