package ejercicio2

open class Animal(
    var MiVelocidad : Int,
    var MiNombre : String = "Sin Nombre"
){
    companion object{
        var animales = 0
        fun cuantosanimaleshay(){
            println("Hay: ${animales} animales")
        }
    }
    init {
        animales++
    }

    open fun saluda(){
    println("Hola soy $MiNombre")
    }
    open fun corre(distancia : Long){
        for(i in 0..distancia){
            var j : Long = 0
            while (j < 10000000){
                j  += MiVelocidad.toLong()
            }
            println(" $MiNombre")
        }
        println("\n $MiNombre ha llegado")
    }
}